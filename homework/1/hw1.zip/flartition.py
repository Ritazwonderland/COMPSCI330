from flippable_list import FlippableList
import random # useful for testing purposes and included example code below

'''COLLABORATION:
- Write the names of anyone/anything that you
consulted besides your partner or course materials here:

TODO: Include colloration notes.
'''

### TODO: FINISH THIS METHOD
def flartition(f, i, j, p):
	'''
	f: FlippableList object
	i: index
	j: index
	p: "pivot" value

	Modifies f._lst[i:j] (where f._lst is its represented list of integers) STRICTLY VIA f.flip OPERATIONS
	so that all elements less than p appear before all elements at least p, then returns the index of
	the first element at least p. If all elements in f._lst[i:j] are less than p, then j is returned.
	'''
	pass

if __name__=='__main__':
	'''Anything below this line will not be ran by the autograder.
	You may use this space to debug your code.'''

	n = 8

	# Example of creating a FlippableList
	L = list(range(1,n+1)) # create a list [1, 2, ..., n]
	a = FlippableList(L)  # create a FlippableList object representing the given list L

	# Example of flip() operation
	print('Before flip(2,5): {}'.format(str(a)))
	a.flip(2,5)
	print('After flip(2,5): {}'.format(str(a)))
	print()

	# Example of checking whether flartition works correctly:
	L = [4, 9, 330, 1, 2, 5, 8, 16]
	a = FlippableList(L)
	print('Before flartition(a, 2, 7, 6): {}'.format(str(a)))
	flartition(a, 2, 7, 6)
	print('After  flartition(a, 2, 7, 6): {}'.format(str(a)))
	print('Is it correct? {}'.format(a.is_parted(2,7,6)))
	print()